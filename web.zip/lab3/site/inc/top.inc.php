<img src="logo.png" width="130" height="80" alt="Наш логотип" class="logo">
<span class="slogan">приходите к нам учиться</span>