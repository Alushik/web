<?php

declare(strict_types=1);

define('DB_NAME', 'f1199297_login_db');
define('DB_USER', 'f1199297_login_db');
define('DB_PASSWORD', '12345678');
define('DB_HOST', 'localhost');
define('DB_CHARSET', 'utf8mb4');